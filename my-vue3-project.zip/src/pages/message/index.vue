<template>
  <!-- 整个页面的容器 -->
  <view class="message-container">
    <!-- 添加背景组件 -->
    <page-background></page-background>
    
    <!-- 状态栏占位 -->
    <view class="status-bar"></view>
    
    <!-- 顶部标题栏 -->
    <view class="header">
      <view class="header-content">
        <text class="title">消息</text>
        <view class="search-btn" @click="toggleSearchBar">
          <text class="iconfont icon-search-line"></text>                       
        </view>
      </view>
    </view>
    
    <!-- 搜索栏 -->
    <view class="search-bar" v-if="showSearchBar">
      <view class="search-input-wrapper">
        <text class="iconfont icon-search"></text>
        <input 
          class="search-input" 
          type="text" 
          v-model="searchKeyword" 
          placeholder="搜索消息" 
          confirm-type="search"
          @confirm="searchMessages"
        />
        <text class="iconfont icon-close-circle-line clear-icon" v-if="searchKeyword" @click="clearSearch"></text>
      </view>
      <text class="cancel-btn" @click="toggleSearchBar">取消</text>
    </view>

    <!-- 消息列表 -->
    <scroll-view class="message-list" scroll-y>
      <view v-if="filteredMessageList.length === 0 && searchKeyword" class="empty-result">
        <text class="iconfont icon-search-none"></text>
        <text class="empty-text">没有找到相关消息</text>
      </view>
      <view 
        class="message-item card" 
        v-for="(item, index) in filteredMessageList" 
        :key="index" 
        @click="onMessageClick(item)" 
        hover-class="message-item-hover"
      >
        <!-- 左侧头像 -->
        <view class="avatar-wrapper">
          <image class="avatar" :src="item.avatar" mode="aspectFill" />
          <view class="unread-badge" v-if="item.unreadCount > 0">
            {{ item.unreadCount }}
          </view>
        </view>
        
        <!-- 右侧内容 -->
        <view class="content-wrapper">
          <view class="content-header">
            <text class="shop-name">{{ item.name }}</text>
            <text class="message-time">{{ item.time }}</text>
          </view>
          <text class="message-preview" :class="{ 'unread': item.unreadCount > 0 }">{{ item.preview }}</text>
        </view>
      </view>
    </scroll-view>

    <!-- 使用TabBar组件 -->
    <tab-bar></tab-bar>
  </view>
</template>

<script setup>
import { ref, computed } from 'vue';
import TabBar from '@/components/TabBar.vue';
import PageBackground from '@/components/PageBackground.vue';

// 搜索相关状态
const showSearchBar = ref(false);
const searchKeyword = ref('');

// 消息列表数据
const messageList = ref([
  {
    avatar: '/src/static/images/default.jpg',
    name: '一楼米饭窗口',
    time: '12:30',
    preview: '今日特价：红烧排骨饭，原价¥15，现价¥12！',
    unreadCount: 2
  },
  {
    avatar: '/src/static/images/default.jpg',
    name: '二楼面食窗口',
    time: '11:45',
    preview: '新品上市：葱油拌面，欢迎品尝！',
    unreadCount: 1
  },
  {
    avatar: '/src/static/images/default.jpg',
    name: '三楼炒菜窗口',
    time: '10:20',
    preview: '中午特惠：小炒黄牛肉，限时优惠！',
    unreadCount: 0
  },
  {
    avatar: '/src/static/images/default.jpg',
    name: '四楼特色窗口',
    time: '昨天',
    preview: '新菜品预告：明天将推出川味担担面！',
    unreadCount: 0
  },
  {
    avatar: '/src/static/images/default.jpg',
    name: '食堂管理处',
    time: '昨天',
    preview: '关于本周食堂营业时间调整的通知',
    unreadCount: 0
  }
]);

// 过滤后的消息列表
const filteredMessageList = computed(() => {
  if (!searchKeyword.value) {
    return messageList.value;
  }
  
  const keyword = searchKeyword.value.toLowerCase();
  return messageList.value.filter(item => {
    return item.name.toLowerCase().includes(keyword) || 
           item.preview.toLowerCase().includes(keyword);
  });
});

// 切换搜索栏显示状态
const toggleSearchBar = () => {
  showSearchBar.value = !showSearchBar.value;
  if (!showSearchBar.value) {
    searchKeyword.value = '';
  }
};

// 清除搜索内容
const clearSearch = () => {
  searchKeyword.value = '';
};

// 处理搜索输入
const handleSearch = () => {
  // 这里可以添加防抖逻辑，优化搜索性能
  console.log('搜索关键词:', searchKeyword.value);
};

// 消息点击处理函数
const onMessageClick = (message) => {
  // 处理消息点击事件
  console.log('点击消息:', message);
};
</script>

<style lang="scss">
.message-container {
  min-height: 100vh;
  padding-bottom: 120rpx;
  box-sizing: border-box;
  position: relative;
}

.status-bar {
  height: var(--status-bar-height, 44px);
}

.header {
  padding: 20rpx 0;
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  box-shadow: 0 4rpx 20rpx rgba(0, 0, 0, 0.05);
}

.header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 30rpx;
  height: 88rpx;
}

.title {
  font-size: 40rpx;
  font-weight: 600;
  color: #333;
  letter-spacing: 1px;
  background: linear-gradient(135deg, #34c759, #32ade6);
  -webkit-background-clip: text;
  color: transparent;
}

.search-btn {
  width: 72rpx;
  height: 72rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(245, 246, 247, 0.8);
  border-radius: 36rpx;
  backdrop-filter: blur(5px);
  transition: all 0.3s ease;
}

.search-btn .iconfont {
  font-size: 36rpx;
  color: #666;
}

.search-btn:active {
  background: rgba(234, 234, 234, 0.9);
  transform: scale(0.95);
}

/* 搜索栏样式 */
.search-bar {
  display: flex;
  align-items: center;
  padding: 20rpx 30rpx;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  animation: slideDown 0.3s ease;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-20rpx);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.search-input-wrapper {
  flex: 1;
  height: 72rpx;
  background: rgba(245, 246, 247, 0.8);
  border-radius: 36rpx;
  display: flex;
  align-items: center;
  padding: 0 20rpx;
  position: relative;
  box-shadow: inset 0 2rpx 5rpx rgba(0, 0, 0, 0.05);
}

.search-input-wrapper .iconfont {
  font-size: 32rpx;
  color: #999;
  margin-right: 10rpx;
}

.search-input {
  flex: 1;
  height: 100%;
  font-size: 28rpx;
  color: #333;
}

.clear-icon {
  font-size: 28rpx;
  color: #999;
  padding: 10rpx;
}

.cancel-btn {
  font-size: 28rpx;
  color: #34c759;
  padding: 0 20rpx;
  font-weight: 500;
}

/* 消息列表样式 */
.message-list {
  padding: 20rpx 30rpx;
  height: calc(100vh - 180rpx);
  box-sizing: border-box;
}

.message-item {
  display: flex;
  padding: 24rpx;
  margin-bottom: 24rpx;
  border-radius: 20rpx;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.message-item::after {
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 3rpx;
  background: linear-gradient(90deg, rgba(52, 199, 89, 0.3), rgba(50, 173, 230, 0.3));
  opacity: 0.6;
}

.message-item-hover {
  transform: translateY(-2rpx);
  box-shadow: 0 10rpx 30rpx rgba(0, 0, 0, 0.08);
}

.avatar-wrapper {
  width: 100rpx;
  height: 100rpx;
  position: relative;
  margin-right: 24rpx;
  flex-shrink: 0;
}

.avatar {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  border: 2rpx solid rgba(255, 255, 255, 0.8);
  box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.1);
}

.unread-badge {
  position: absolute;
  top: -6rpx;
  right: -6rpx;
  min-width: 36rpx;
  height: 36rpx;
  border-radius: 18rpx;
  background: #ff3b30;
  color: #fff;
  font-size: 22rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 8rpx;
  box-sizing: border-box;
  box-shadow: 0 2rpx 6rpx rgba(255, 59, 48, 0.4);
  border: 2rpx solid #fff;
  font-weight: 600;
}

.content-wrapper {
  flex: 1;
  overflow: hidden;
}

.content-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10rpx;
}

.shop-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.message-time {
  font-size: 24rpx;
  color: #999;
  flex-shrink: 0;
  margin-left: 16rpx;
}

.message-preview {
  font-size: 28rpx;
  color: #666;
  line-height: 1.5;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.message-preview.unread {
  color: #333;
  font-weight: 500;
}

/* 空结果样式 */
.empty-result {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 100rpx 0;
}

.empty-result .iconfont {
  font-size: 80rpx;
  color: #ccc;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}

/* 适配不同屏幕 */
@media screen and (max-width: 375px) {
  .message-item {
    padding: 20rpx;
    margin-bottom: 20rpx;
  }
  
  .avatar-wrapper {
    width: 90rpx;
    height: 90rpx;
    margin-right: 20rpx;
  }
  
  .shop-name {
    font-size: 30rpx;
  }
  
  .message-preview {
    font-size: 26rpx;
  }
}
</style>