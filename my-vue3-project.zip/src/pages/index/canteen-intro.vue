<template>
  <view class="container">
    <!-- 添加页面背景 -->
    <page-background></page-background>
    
    <!-- 顶部安全区域，适配不同手机状态栏 -->
    <view class="status-bar safe-area-inset-top"></view>
    
    <!-- 顶部导航栏 -->
    <view class="nav-header">
      <view class="back-icon" @click="goBack">
        <text class="iconfont icon-arrow-left-s-line"></text>
      </view>
      <text class="header-title">餐厅介绍</text>
    </view>

    <!-- 选择器区域 -->
    <view class="selector-area container-wrapper card">
      <view class="selector-item">
        <picker :range="canteenOptions" range-key="text" @change="onCanteenChange">
          <view class="picker-content">
            <text class="picker-label">餐厅</text>
            <view class="picker-value-wrapper">
              <text class="picker-value">{{ selectedCanteen ? selectedCanteen.text : '选择餐厅' }}</text>
              <text class="iconfont icon-arrow-down"></text>
            </view>
          </view>
        </picker>
      </view>
      <view class="selector-divider"></view>
      <view class="selector-item">
        <picker :range="floorOptions" range-key="text" @change="onFloorChange">
          <view class="picker-content">
            <text class="picker-label">楼层</text>
            <view class="picker-value-wrapper">
              <text class="picker-value">{{ selectedFloor ? selectedFloor.text : '选择楼层' }}</text>
              <text class="iconfont icon-arrow-down"></text>
            </view>
          </view>
        </picker>
      </view>
    </view>

    <!-- 食品列表部分改为窗口列表 -->
    <scroll-view class="food-list" scroll-y>
      <view class="window-section" v-if="foodList && foodList.length > 0">
        <view 
          class="window-card card" 
          v-for="(window, index) in foodList" 
          :key="index"
          @tap="directGoToDishList(window)"
        >
          <image class="window-image" :src="window.image || '/static/images/default.jpg'" mode="aspectFill"></image>
          <view class="window-info">
            <view class="window-name">{{window.name}}</view>
            <view class="window-desc">{{window.description}}</view>
            <view class="window-times">
              <view class="time-slots">
                <view class="time-tag">午餐</view>
                <view class="time-value">{{window.lunchTime}}</view>
              </view>
              <view class="time-slots">
                <view class="time-tag">晚餐</view>
                <view class="time-value">{{window.dinnerTime}}</view>
              </view>
            </view>
          </view>
        </view>
      </view>
      <view class="empty-state" v-else>
        <image src="/static/images/default.jpg" mode="aspectFit"></image>
        <text>暂无窗口信息</text>
      </view>
    </scroll-view>
    
    <!-- 餐厅详情弹窗 -->
    <view class="popup-mask" v-if="showCanteenPopup" @click="closePopup"></view>
    <view class="canteen-popup card" v-if="showCanteenPopup">
      <view class="popup-header">
        <text class="popup-title">{{ currentCanteen.name }}</text>
        <view class="popup-close" @click="closePopup">
          <text class="iconfont icon-close-circle-line"></text>
        </view>
      </view>
      
      <view class="popup-content">
        <view class="popup-image">
          <image :src="currentCanteen.image" mode="aspectFill"></image>
        </view>
        
        <view class="popup-info">
          <view class="info-item">
            <text class="info-label">餐厅简介</text>
            <text class="info-value">{{ currentCanteen.description }}</text>
          </view>
          
          <view class="info-item">
            <text class="info-label">营业时间</text>
            <view class="time-info">
              <view class="time-item">
                <text class="time-label">午餐：</text>
                <text class="time-value">{{ currentCanteen.lunchTime }}</text>
              </view>
              <view class="time-item">
                <text class="time-label">晚餐：</text>
                <text class="time-value">{{ currentCanteen.dinnerTime }}</text>
              </view>
            </view>
          </view>
          
          <view class="info-item">
            <text class="info-label">位置信息</text>
            <view class="location-info">
              <text class="location-value">{{ currentCanteen.location }}</text>
              <view class="location-map" @click="navigateToLocation">
                <text class="iconfont icon-location"></text>
                <text>导航</text>
              </view>
            </view>
          </view>
        </view>
        
        <view class="popup-footer">
          <view class="popup-btn btn" @click="viewFoodWindows(currentCanteen)">
            <text>查看窗口</text>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 窗口详情弹窗 -->
    <view class="popup-mask" v-if="showWindowPopup" @click="closeWindowPopup"></view>
    <view class="window-popup card" v-if="showWindowPopup">
      <view class="popup-header">
        <text class="popup-title">{{ currentWindow.name }}</text>
        <view class="popup-close" @click="closeWindowPopup">
          <text class="iconfont icon-close-circle-line"></text>
        </view>
      </view>
      
      <view class="popup-content">
        <view class="popup-image">
          <image :src="currentWindow.image" mode="aspectFill"></image>
        </view>
        
        <view class="popup-info">
          <view class="info-item">
            <text class="info-label">窗口简介</text>
            <text class="info-value">{{ currentWindow.description }}</text>
          </view>
          
          <view class="info-item">
            <text class="info-label">营业时间</text>
            <view class="time-info">
              <view class="time-item">
                <text class="time-label">午餐：</text>
                <text class="time-value">{{ currentWindow.lunchTime }}</text>
              </view>
              <view class="time-item">
                <text class="time-label">晚餐：</text>
                <text class="time-value">{{ currentWindow.dinnerTime }}</text>
              </view>
            </view>
          </view>
        </view>
        
        <view class="popup-footer">
          <view class="popup-btn btn" @click="directGoToDishList(currentWindow)">
            <text class="btn-icon">&#x1F374;</text>
            <text>查看菜品</text>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 使用TabBar组件代替自定义底部导航栏 -->
    <tab-bar></tab-bar>
  </view>
</template>

<script>
import TabBar from '@/components/TabBar.vue';
import PageBackground from '@/components/PageBackground.vue';

export default {
  components: {
    TabBar,
    PageBackground
  },
  data() {
    return {
      selectedCanteen: null,
      selectedFloor: null,
      showCanteenPopup: false,
      showWindowPopup: false,
      currentCanteen: {},
      currentWindow: null,
      // 当前显示的食堂ID
      currentCanteenId: null,
      canteenOptions: [
        { value: '1', text: '第一食堂' },
        { value: '2', text: '第二食堂' },
        { value: '3', text: '第三食堂' }
      ],
      floorOptions: [
        { value: '1', text: '一楼' },
        { value: '2', text: '二楼' },
        { value: '3', text: '三楼' }
      ],
      canteenDetails: [
        {
          id: '1',
          name: '第一食堂',
          description: '第一食堂位于学校东区，主要提供川菜、粤菜等多种风味的美食，环境整洁舒适，是师生用餐的首选场所。',
          image: '/static/images/default.jpg',
          location: '校区东门旁边，综合教学楼一层',
          coordinates: {
            latitude: 30.123456,
            longitude: 120.123456
          },
          lunchTime: '10:30-14:00',
          dinnerTime: '16:30-19:30',
          windows: [
            {
              name: '川菜窗口',
              description: '提供正宗川菜，麻辣鲜香，品种丰富。',
              image: '/static/images/default.jpg',
              lunchTime: '10:30-14:00',
              dinnerTime: '16:30-19:30'
            },
            {
              name: '粤菜窗口',
              description: '广东风味，清淡鲜美，营养丰富。',
              image: '/static/images/default.jpg',
              lunchTime: '10:30-14:00',
              dinnerTime: '16:30-19:30'
            },
            {
              name: '面食窗口',
              description: '各式面食，现做现卖，口感极佳。',
              image: '/static/images/default.jpg',
              lunchTime: '10:30-14:00',
              dinnerTime: '16:30-19:30'
            }
          ]
        },
        {
          id: '2',
          name: '第二食堂',
          description: '第二食堂位于学校中区，专注于提供北方特色餐饮，有面食窗口、饺子窗口等，价格实惠，深受北方学生喜爱。',
          image: '/static/images/default.jpg',
          location: '校区中央，图书馆西侧',
          coordinates: {
            latitude: 30.234567,
            longitude: 120.234567
          },
          lunchTime: '10:50-14:00',
          dinnerTime: '17:00-19:00',
          windows: [
            {
              name: '北方面食窗口',
              description: '正宗北方面食，劲道爽滑，品种多样。',
              image: '/static/images/default.jpg',
              lunchTime: '10:50-14:00',
              dinnerTime: '17:00-19:00'
            },
            {
              name: '饺子馄饨窗口',
              description: '现包现煮，馅料丰富，汤鲜味美。',
              image: '/static/images/default.jpg',
              lunchTime: '10:50-14:00',
              dinnerTime: '17:00-19:00'
            }
          ]
        },
        {
          id: '3',
          name: '第三食堂',
          description: '第三食堂是学校最新建成的现代化食堂，提供多种国际美食，包括日韩料理、西式快餐等，环境优雅，设施完善。',
          image: '/static/images/default.jpg',
          location: '校区西区，学生宿舍区域',
          coordinates: {
            latitude: 30.345678,
            longitude: 120.345678
          },
          lunchTime: '11:00-13:30',
          dinnerTime: '17:30-20:00',
          windows: [
            {
              name: '日韩料理窗口',
              description: '正宗日韩风味，食材新鲜，制作精细。',
              image: '/static/images/default.jpg',
              lunchTime: '11:00-13:30',
              dinnerTime: '17:30-20:00'
            },
            {
              name: '西式快餐窗口',
              description: '各式西餐，制作标准，风味独特。',
              image: '/static/images/default.jpg',
              lunchTime: '11:00-13:30',
              dinnerTime: '17:30-20:00'
            },
            {
              name: '创意料理窗口',
              description: '融合中西方元素，创新菜品，别具一格。',
              image: '/static/images/default.jpg',
              lunchTime: '11:00-13:30',
              dinnerTime: '17:30-20:00'
            }
          ]
        }
      ],
      // 默认显示的窗口列表
      foodList: [
        {
          name: '炒肉窗口',
          description: '精选五花肉，配以青椒、蒜苗等新鲜食材，口感鲜美，营养均衡。',
          image: '/static/images/default.jpg',
          lunchTime: '10:50-14:00',
          dinnerTime: '16:30-18:50'
        },
        {
          name: '猪脚饭窗口',
          description: '选用上等猪脚，经过多小时炖煮，肉质软烂，搭配特制酱料。',
          image: '/static/images/default.jpg',
          lunchTime: '10:50-14:00',
          dinnerTime: '16:30-18:50'
        },
        {
          name: '面食窗口',
          description: '精选牛杂，搭配手工面条，汤底浓郁，营养丰富。',
          image: '/static/images/default.jpg',
          lunchTime: '10:50-14:00',
          dinnerTime: '16:30-18:50'
        }
      ]
    }
  },
  onShow() {
    // 每次页面显示时重置餐厅选择器状态
    this.resetPickerState();
  },
  methods: {
    resetPickerState() {
      // 清空之前选择的餐厅状态，确保下次能正常弹窗
      this.showCanteenPopup = false;
    },
    goBack() {
      uni.navigateTo({
        url: '/pages/index/index'
      });
    },
    onCanteenChange(e) {
      // 更新选中的餐厅
      this.selectedCanteen = this.canteenOptions[e.detail.value];
      
      // 查找对应的餐厅详情
      const canteenId = this.selectedCanteen.value;
      const canteen = this.canteenDetails.find(item => item.id === canteenId);
      
      if (canteen) {
        // 显示餐厅详情弹窗
        this.showCanteenDetail(canteen);
      }
    },
    onFloorChange(e) {
      this.selectedFloor = this.floorOptions[e.detail.value];
      
      // 这里可以根据楼层筛选餐厅列表
      this.filterFoodList();
    },
    // 根据选择的餐厅和楼层筛选餐厅列表
    filterFoodList() {
      // 这里可以添加筛选逻辑
      console.log('筛选条件：', this.selectedCanteen, this.selectedFloor);
    },
    // 点击列表项查看餐厅详情
    viewCanteenDetail(item) {
      // 根据名称查找对应的餐厅详情
      const canteen = this.canteenDetails.find(c => c.name === item.name);
      
      if (canteen) {
        this.showCanteenDetail(canteen);
      } else {
        // 如果没找到对应的餐厅详情，直接使用列表项作为详情
        this.currentCanteen = {
          ...item,
          description: item.description || '暂无详细介绍',
          location: '详细位置信息暂未提供',
          coordinates: null
        };
        this.showCanteenPopup = true;
      }
    },
    // 显示餐厅详情弹窗
    showCanteenDetail(canteen) {
      // 无论是否选择相同的餐厅，都更新当前餐厅并显示弹窗
      this.currentCanteen = canteen;
      
      // 先关闭再打开弹窗，确保状态正确刷新
      this.showCanteenPopup = false;
      setTimeout(() => {
        this.showCanteenPopup = true;
        
        // 获取位置信息
        this.getCanteenLocation(canteen);
      }, 50);
    },
    viewFoodWindows(item) {
      // 关闭弹窗
      this.closePopup();
      
      // 更新页面标题以反映当前正在查看的食堂窗口
      uni.setNavigationBarTitle({
        title: `${item.name}的窗口`
      });
      
      // 根据所选食堂筛选窗口列表
      this.filterWindowsByCanteen(item.name);
    },
    // 根据食堂名称筛选窗口列表
    filterWindowsByCanteen(canteenName) {
      console.log(`筛选${canteenName}的窗口`);
      
      // 根据食堂名称查找食堂详情
      const canteen = this.canteenDetails.find(c => c.name === canteenName);
      
      if (canteen && canteen.windows) {
        // 更新当前显示的食堂ID
        this.currentCanteenId = canteen.id;
        
        // 更新窗口列表为该食堂的窗口
        this.foodList = canteen.windows;
        
        // 更新页面标题
        uni.setNavigationBarTitle({
          title: `${canteenName}的窗口`
        });
        
        // 更新页面头部标题
        this.$nextTick(() => {
          const headerTitleEl = document.querySelector('.header-title');
          if (headerTitleEl) {
            headerTitleEl.textContent = `${canteenName}的窗口`;
          }
        });
        
        // 提示用户
        uni.showToast({
          title: `正在查看${canteenName}窗口`,
          icon: 'none',
          duration: 2000
        });
      } else {
        console.error(`未找到${canteenName}的窗口信息`);
        uni.showToast({
          title: '暂无窗口信息',
          icon: 'none'
        });
      }
    },
    closePopup() {
      this.showCanteenPopup = false;
    },
    // 获取餐厅位置信息
    getCanteenLocation(canteen) {
      // 如果餐厅已有坐标信息，直接使用
      if (canteen.coordinates && canteen.coordinates.latitude) {
        console.log('使用预设坐标:', canteen.coordinates);
        return;
      }
      
      // 尝试获取当前位置
      uni.getLocation({
        type: 'gcj02',
        success: (res) => {
          console.log('当前位置:', res);
          // 这里可以将位置信息保存到餐厅数据中
          // 或者可以计算用户与餐厅的距离
        },
        fail: (err) => {
          console.error('获取位置失败:', err);
          uni.showToast({
            title: '获取位置信息失败',
            icon: 'none'
          });
        }
      });
    },
    // 导航到餐厅位置
    navigateToLocation() {
      const { coordinates, name } = this.currentCanteen;
      
      if (coordinates && coordinates.latitude) {
        uni.openLocation({
          latitude: coordinates.latitude,
          longitude: coordinates.longitude,
          name: name,
          address: this.currentCanteen.location,
          success: () => {
            console.log('打开位置成功');
          },
          fail: (err) => {
            console.error('打开位置失败:', err);
            uni.showToast({
              title: '打开地图失败',
              icon: 'none'
            });
          }
        });
      } else {
        uni.showToast({
          title: '位置信息不完整',
          icon: 'none'
        });
      }
    },
    viewWindowDetail(window) {
      console.log('查看窗口详情:', window);
      
      // 先显示窗口详情弹窗
      this.currentWindow = window;
      this.showWindowPopup = true;
      
      // 添加弹窗中的查看菜品按钮功能
      this.currentWindow.viewDishes = () => {
        // 关闭弹窗
        this.closeWindowPopup();
        
        // 跳转到菜品列表页面，并传递窗口信息
        setTimeout(() => {
          uni.navigateTo({
            url: `/pages/index/dish-list?windowId=${window.id || ''}&windowName=${encodeURIComponent(window.name)}`,
            success: () => {
              console.log('跳转到菜品列表页面成功');
            },
            fail: (err) => {
              console.error('跳转到菜品列表页面失败:', err);
              uni.showToast({
                title: '跳转失败，显示窗口详情',
                icon: 'none',
                duration: 2000
              });
            }
          });
        }, 300);
      };
    },
    closeWindowPopup() {
      this.showWindowPopup = false;
      setTimeout(() => {
        this.currentWindow = null;
      }, 300);
    },
    goToDishList(window) {
      console.log('跳转到菜品列表:', window);
      
      // 直接跳转到菜品列表页面
      uni.navigateTo({
        url: `/pages/index/dish-list?windowId=${window.id || ''}&windowName=${encodeURIComponent(window.name)}`,
        success: () => {
          console.log('跳转到菜品列表页面成功');
        },
        fail: (err) => {
          console.error('跳转到菜品列表页面失败:', err);
          
          // 如果跳转失败，显示错误信息并尝试查看窗口详情
          uni.showToast({
            title: '跳转失败，显示窗口详情',
            icon: 'none',
            duration: 2000
          });
          
          // 退回到显示窗口详情
          this.viewWindowDetail(window);
        }
      });
    },
    directGoToDishList(window) {
      console.log('直接跳转到菜品列表:', window);
      
      // 先关闭弹窗
      this.closeWindowPopup();
      
      // 延迟一下再跳转，确保弹窗已经关闭
      setTimeout(() => {
        // 使用reLaunch方法替代navigateTo，确保能正确跳转
        uni.reLaunch({
          url: `/pages/index/dish-list?windowId=${window.id || ''}&windowName=${encodeURIComponent(window.name)}`,
          success: () => {
            console.log('跳转到菜品列表页面成功');
          },
          fail: (err) => {
            console.error('跳转到菜品列表页面失败:', err);
            
            // 如果reLaunch失败，尝试使用redirectTo
            uni.redirectTo({
              url: `/pages/index/dish-list?windowId=${window.id || ''}&windowName=${encodeURIComponent(window.name)}`,
              fail: (err2) => {
                console.error('redirectTo也失败了:', err2);
                
                // 最后尝试navigateTo
                uni.navigateTo({
                  url: `/pages/index/dish-list?windowId=${window.id || ''}&windowName=${encodeURIComponent(window.name)}`
                });
              }
            });
          }
        });
      }, 300);
    }
  }
}
</script>

<style lang="scss">
.container {
  min-height: 100vh;
  padding-bottom: 110rpx;
  box-sizing: border-box;
  position: relative;
}

.status-bar {
  height: var(--status-bar-height, 44px);
}

.nav-header {
  display: flex;
  align-items: center;
  padding: 20rpx 30rpx;
  position: relative;
  z-index: 10;
}

.back-icon {
  width: 60rpx;
  height: 60rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 50%;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(5px);
}

.back-icon .iconfont {
  font-size: 40rpx;
  color: #333;
}

.header-title {
  flex: 1;
  text-align: center;
  font-size: 36rpx;
  font-weight: 600;
  color: #333;
  margin-right: 60rpx;
}

/* 选择器区域样式 */
.selector-area {
  margin: 20rpx 30rpx 40rpx;
  display: flex;
  padding: 24rpx 30rpx;
  border-radius: 20rpx;
  position: relative;
  z-index: 1;
}

.selector-divider {
  width: 2rpx;
  background: rgba(0, 0, 0, 0.05);
  margin: 0 30rpx;
}

.selector-item {
  flex: 1;
}

.picker-content {
  display: flex;
  flex-direction: column;
}

.picker-label {
  font-size: 24rpx;
  color: #666;
  margin-bottom: 8rpx;
}

.picker-value-wrapper {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.picker-value {
  font-size: 32rpx;
  color: #333;
  font-weight: 500;
}

.icon-arrow-down {
  font-size: 28rpx;
  color: #999;
  margin-left: 10rpx;
  transition: transform 0.3s ease;
}

/* 窗口列表样式 */
.food-list {
  height: calc(100vh - 300rpx);
  padding: 0 30rpx;
  box-sizing: border-box;
}

.window-section {
  padding-bottom: 30rpx;
}

.window-card {
  margin-bottom: 30rpx;
  border-radius: 20rpx;
  overflow: hidden;
  position: relative;
  transition: all 0.3s ease;
}

.window-card:active {
  transform: translateY(-2rpx);
  box-shadow: 0 12rpx 30rpx rgba(0, 0, 0, 0.1);
}

.window-image {
  width: 100%;
  height: 240rpx;
  object-fit: cover;
}

.window-info {
  padding: 24rpx;
}

.window-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 12rpx;
}

.window-desc {
  font-size: 26rpx;
  color: #666;
  margin-bottom: 20rpx;
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}

.window-times {
  display: flex;
  gap: 30rpx;
}

.time-slots {
  display: flex;
  align-items: center;
}

.time-tag {
  font-size: 24rpx;
  padding: 4rpx 16rpx;
  background: rgba(52, 199, 89, 0.1);
  color: #34c759;
  border-radius: 20rpx;
  margin-right: 10rpx;
}

.time-value {
  font-size: 24rpx;
  color: #666;
}

/* 弹窗样式 */
.popup-mask {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 100;
  backdrop-filter: blur(5px);
}

.canteen-popup,
.window-popup {
  position: fixed;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 90%;
  max-width: 650rpx;
  max-height: 80vh;
  z-index: 101;
  border-radius: 24rpx;
  overflow: hidden;
}

.popup-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24rpx 30rpx;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.popup-title {
  font-size: 36rpx;
  font-weight: 600;
  color: #333;
}

.popup-close {
  width: 60rpx;
  height: 60rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
}

.popup-close:active {
  background: rgba(0, 0, 0, 0.1);
}

.popup-close .iconfont {
  font-size: 40rpx;
  color: #666;
}

.popup-content {
  padding: 0;
  max-height: calc(80vh - 100rpx);
  overflow-y: auto;
}

.popup-image {
  width: 100%;
  height: 300rpx;
  overflow: hidden;
}

.popup-image image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.popup-info {
  padding: 30rpx;
}

.info-item {
  margin-bottom: 30rpx;
}

.info-label {
  font-size: 28rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 16rpx;
  display: block;
  position: relative;
  padding-left: 20rpx;
}

.info-label::before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 6rpx;
  height: 24rpx;
  background: linear-gradient(to bottom, #34c759, #32ade6);
  border-radius: 3rpx;
}

.info-value {
  font-size: 26rpx;
  color: #666;
  line-height: 1.6;
}

.time-info {
  display: flex;
  flex-direction: column;
  gap: 12rpx;
}

.time-item {
  display: flex;
  align-items: center;
}

.time-label {
  font-size: 26rpx;
  color: #666;
  width: 100rpx;
}

.time-value {
  font-size: 26rpx;
  color: #333;
  font-weight: 500;
}

.location-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.location-value {
  font-size: 26rpx;
  color: #666;
  flex: 1;
}

.location-map {
  display: flex;
  align-items: center;
  padding: 10rpx 20rpx;
  background: rgba(52, 199, 89, 0.1);
  border-radius: 30rpx;
  color: #34c759;
}

.location-map .iconfont {
  font-size: 28rpx;
  margin-right: 8rpx;
}

.popup-footer {
  padding: 20rpx 30rpx 30rpx;
  display: flex;
  justify-content: center;
}

.popup-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20rpx 60rpx;
  border-radius: 50rpx;
  font-size: 28rpx;
  font-weight: 500;
  color: #fff;
  background: linear-gradient(135deg, #34c759, #32ade6);
  box-shadow: 0 8rpx 20rpx rgba(52, 199, 89, 0.3);
  transition: all 0.3s ease;
}

.popup-btn:active {
  transform: translateY(2rpx);
  box-shadow: 0 4rpx 10rpx rgba(52, 199, 89, 0.2);
}

.btn-icon {
  margin-right: 10rpx;
}

/* 空状态样式 */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 100rpx 0;
}

.empty-state image {
  width: 200rpx;
  height: 200rpx;
  margin-bottom: 30rpx;
  opacity: 0.5;
}

.empty-state text {
  font-size: 28rpx;
  color: #999;
}

/* 适配不同屏幕 */
@media screen and (max-width: 375px) {
  .window-card {
    margin-bottom: 20rpx;
  }
  
  .window-image {
    height: 200rpx;
  }
  
  .window-name {
    font-size: 28rpx;
  }
  
  .window-desc {
    font-size: 24rpx;
  }
  
  .time-tag {
    font-size: 22rpx;
  }
  
  .time-value {
    font-size: 22rpx;
  }
}
</style> 