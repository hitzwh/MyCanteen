<template>
  <view class="container">
    <!-- 顶部安全区域，适配不同手机状态栏 -->
    <view class="status-bar safe-area-inset-top"></view>
    
    <!-- 顶部导航栏 -->
    <view class="nav-header">
      <view class="back-icon" @click="goBack">
        <text>&#8592;</text>
      </view>
      <text class="header-title">{{ windowName }}的菜品</text>
    </view>

    <!-- 选择器区域 -->
    <view class="selector-area">
      <view class="selector-item">
        <picker :range="typeOptions" range-key="text" @change="onTypeChange">
          <view class="picker-content">
            <text class="picker-value">{{ selectedType ? selectedType.text : '荤/素' }}</text>
            <text class="picker-arrow">&#9662;</text>
          </view>
        </picker>
      </view>
      <view class="selector-divider"></view>
      <view class="selector-item">
        <picker :range="supplyOptions" range-key="text" @change="onSupplyChange">
          <view class="picker-content">
            <text class="picker-value">{{ selectedSupply ? selectedSupply.text : '供应' }}</text>
            <text class="picker-arrow">&#9662;</text>
          </view>
        </picker>
      </view>
    </view>

    <!-- 菜品列表 -->
    <scroll-view class="dish-list" scroll-y>
      <view class="dish-section" v-if="filteredDishes && filteredDishes.length > 0">
        <view 
          class="dish-card" 
          v-for="(dish, index) in filteredDishes" 
          :key="index"
          @tap="viewDishDetail(dish)"
        >
          <image class="dish-image" :src="dish.image || '/static/images/default.jpg'" mode="aspectFill"></image>
          <view class="dish-info">
            <view class="dish-header">
              <view class="dish-name">
                <text class="dish-dot">•</text>
                <text>{{dish.name}}</text>
              </view>
            </view>
            <view class="dish-desc">{{dish.description}}</view>
            <view class="dish-footer">
              <view class="dish-price">
                <text class="price-symbol">¥</text>
                <text class="price-value">{{dish.price}}</text>
              </view>
            </view>
          </view>
        </view>
      </view>
      <view class="empty-state" v-else>
        <image src="/static/images/default.jpg" mode="aspectFit"></image>
        <text>暂无菜品信息</text>
      </view>
    </scroll-view>
    
    <!-- 使用TabBar组件代替自定义底部导航栏 -->
    <tab-bar></tab-bar>
  </view>
</template>

<script>
import TabBar from '@/components/TabBar.vue';

export default {
  components: {
    TabBar
  },
  data() {
    return {
      windowId: '',
      windowName: '',
      // 选择器选项
      typeOptions: [
        { value: 'all', text: '全部' },
        { value: 'meat', text: '荤菜' },
        { value: 'vegetable', text: '素菜' },
        { value: 'mixed', text: '荤素搭配' }
      ],
      supplyOptions: [
        { value: 'all', text: '全部' },
        { value: 'available', text: '供应中' },
        { value: 'unavailable', text: '已售完' }
      ],
      selectedType: null,
      selectedSupply: null,
      // 菜品数据
      dishes: [
        {
          id: '1',
          name: '小炒黄牛肉',
          description: '精选黄牛肉，配以青椒、蒜苗等新鲜食材，口感鲜美，营养均衡。',
          image: '/static/images/default.jpg',
          price: '16.00',
          type: 'meat',
          supply: 'available'
        },
        {
          id: '2',
          name: '炸鸡腿',
          description: '选用上等鸡腿，经过特殊工艺炸制，外酥里嫩，美味可口。',
          image: '/static/images/default.jpg',
          price: '16.00',
          type: 'meat',
          supply: 'available'
        },
        {
          id: '3',
          name: '青椒土豆丝',
          description: '新鲜土豆丝，搭配青椒爆炒，清脆爽口，开胃下饭。',
          image: '/static/images/default.jpg',
          price: '10.00',
          type: 'vegetable',
          supply: 'available'
        },
        {
          id: '4',
          name: '麻婆豆腐',
          description: '嫩滑豆腐配以香辣酱料，麻辣鲜香，回味无穷。',
          image: '/static/images/default.jpg',
          price: '12.00',
          type: 'mixed',
          supply: 'unavailable'
        }
      ]
    }
  },
  computed: {
    // 根据筛选条件过滤菜品
    filteredDishes() {
      let result = this.dishes;
      
      // 按类型筛选
      if (this.selectedType && this.selectedType.value !== 'all') {
        result = result.filter(dish => dish.type === this.selectedType.value);
      }
      
      // 按供应状态筛选
      if (this.selectedSupply && this.selectedSupply.value !== 'all') {
        result = result.filter(dish => dish.supply === this.selectedSupply.value);
      }
      
      return result;
    }
  },
  onLoad(options) {
    // 获取传递的窗口ID和名称
    if (options.windowId) {
      this.windowId = options.windowId;
    }
    if (options.windowName) {
      this.windowName = decodeURIComponent(options.windowName);
    }
    
    // 设置默认选项
    this.selectedType = this.typeOptions[0]; // 默认选择"全部"
    this.selectedSupply = this.supplyOptions[0]; // 默认选择"全部"
    
    // 加载菜品数据
    this.loadDishes();
  },
  methods: {
    goBack() {
      // 直接跳转到餐厅介绍页面，而不是使用navigateBack
      console.log('返回到餐厅介绍页面');
      
      // 使用reLaunch方法替代redirectTo，确保能正确返回
      uni.reLaunch({
        url: '/pages/index/canteen-intro',
        success: () => {
          console.log('成功返回到餐厅介绍页面');
        },
        fail: (err) => {
          console.error('返回失败:', err);
          
          // 如果reLaunch失败，尝试使用redirectTo
          uni.redirectTo({
            url: '/pages/index/canteen-intro',
            fail: (err2) => {
              console.error('redirectTo也失败了:', err2);
              
              // 最后尝试navigateTo
              uni.navigateTo({
                url: '/pages/index/canteen-intro'
              });
            }
          });
        }
      });
    },
    // 加载菜品数据
    loadDishes() {
      // 这里可以根据windowId从服务器加载菜品数据
      console.log(`加载窗口ID为${this.windowId}的菜品数据`);
      
      // 模拟从服务器加载数据
      // 实际项目中，这里应该调用API获取数据
      // this.dishes = [...从服务器获取的数据];
    },
    // 查看菜品详情
    viewDishDetail(dish) {
      console.log('查看菜品详情:', dish);
      
      // 跳转到菜品详情页面，并传递窗口信息
      let url = `/pages/index/dish-detail?dishId=${dish.id}`;
      
      // 添加窗口ID和名称参数，以便返回时能回到正确的菜品列表
      if (this.windowId) {
        url += `&windowId=${this.windowId}`;
      }
      if (this.windowName) {
        url += `&windowName=${encodeURIComponent(this.windowName)}`;
      }
      
      uni.navigateTo({
        url: url,
        success: () => {
          console.log('跳转到菜品详情页面成功');
        },
        fail: (err) => {
          console.error('跳转到菜品详情页面失败:', err);
          uni.showToast({
            title: '跳转失败，请重试',
            icon: 'none'
          });
        }
      });
    },
    // 菜品类型选择变化
    onTypeChange(e) {
      this.selectedType = this.typeOptions[e.detail.value];
      console.log('选择的菜品类型:', this.selectedType);
    },
    // 供应状态选择变化
    onSupplyChange(e) {
      this.selectedSupply = this.supplyOptions[e.detail.value];
      console.log('选择的供应状态:', this.selectedSupply);
    }
  }
}
</script>

<style lang="scss">
.container {
  min-height: 100vh;
  background-color: #f8f8f8;
  position: relative;
  width: 100%;
  box-sizing: border-box;
}

.status-bar {
  width: 100%;
  height: var(--status-bar-height);
  background-color: #ffffff;
}

.nav-header {
  position: relative;
  height: 90rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #ffffff;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
  width: 100%;
  z-index: 100;

  .back-icon {
    position: absolute;
    left: 20rpx;
    width: 64rpx;
    height: 64rpx;
    border-radius: 50%;
    background-color: rgba(0, 0, 0, 0.03);
    font-size: 40rpx;
    color: #333;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
    
    &:active {
      background-color: rgba(0, 0, 0, 0.08);
    }
    
    text {
      font-weight: bold;
    }
  }

  .header-title {
    font-size: 36rpx;
    font-weight: bold;
    color: #333;
    position: relative;
    
    &:after {
      content: '';
      position: absolute;
      bottom: -8rpx;
      left: 50%;
      transform: translateX(-50%);
      width: 60rpx;
      height: 6rpx;
      background-color: #ff9500;
      border-radius: 3rpx;
      opacity: 0.8;
    }
  }
}

/* 选择器区域样式 */
.selector-area {
  display: flex;
  align-items: center;
  background-color: #ffffff;
  padding: 0;
  border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
  height: 100rpx;
}

.selector-item {
  flex: 1;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.selector-divider {
  width: 1px;
  height: 50%;
  background-color: rgba(0, 0, 0, 0.1);
}

.picker-content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  padding: 0 20rpx;
}

.picker-value {
  font-size: 28rpx;
  color: #333;
  margin-right: 10rpx;
}

.picker-arrow {
  font-size: 24rpx;
  color: #999;
  margin-left: 6rpx;
}

.dish-list {
  padding: 0 20rpx 30rpx;
  height: calc(100vh - 90rpx - var(--status-bar-height) - 100rpx - 100rpx);
  background-color: #f8f8f8;

  .dish-section {
    display: flex;
    flex-direction: column;
    gap: 30rpx;
    padding: 30rpx 0;
  }
  
  /* 菜品卡片样式 */
  .dish-card {
    width: 100%;
    display: flex;
    background-color: #ffffff;
    border-radius: 12rpx;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    position: relative;
    border: 1px solid rgba(0, 0, 0, 0.05);
    box-sizing: border-box;
    padding: 10rpx;
    
    .dish-image {
      width: 160rpx;
      height: 160rpx;
      object-fit: cover;
      flex-shrink: 0;
      margin-right: 15rpx;
      border-radius: 8rpx;
    }

    .dish-info {
      flex: 1;
      display: flex;
      flex-direction: column;
      padding: 10rpx 15rpx;
      overflow: hidden;
      min-width: 0;
      margin-right: 10rpx;
    }
    
    .dish-header {
      width: 100%;
      margin-bottom: 15rpx;
    }

    .dish-name {
      font-size: 30rpx;
      font-weight: 600;
      color: #333;
      display: flex;
      align-items: center;
      padding-right: 15rpx;
      
      .dish-dot {
        color: #ff9500;
        font-size: 36rpx;
        margin-right: 8rpx;
        line-height: 1;
        flex-shrink: 0;
      }
      
      text {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
    }

    .dish-desc {
      font-size: 24rpx;
      color: #666;
      line-height: 1.6;
      margin-bottom: 15rpx;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
      word-break: break-all;
      flex: 1;
      padding-right: 10rpx;
    }
    
    .dish-footer {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      width: 100%;
      margin-top: 5rpx;
    }
    
    .dish-price {
      color: #ff6200;
      font-weight: bold;
      display: flex;
      align-items: baseline;
      flex-shrink: 0;
      padding-right: 15rpx;
      
      .price-symbol {
        font-size: 24rpx;
        margin-right: 4rpx;
      }
      
      .price-value {
        font-size: 32rpx;
      }
    }
  }

  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 80rpx 30rpx;
    height: 400rpx;

    image {
      width: 160rpx;
      height: 160rpx;
      margin-bottom: 30rpx;
      opacity: 0.8;
    }

    text {
      font-size: 28rpx;
      color: #999;
      line-height: 1.4;
      text-align: center;
    }
  }
}
</style> 