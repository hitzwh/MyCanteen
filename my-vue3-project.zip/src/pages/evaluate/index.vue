<template>
  <!-- 整个页面的容器 -->
  <view class="evaluate-container">
    <!-- 状态栏占位 -->
    <view class="status-bar"></view>
    
    <!-- 筛选栏 -->
    <view class="filter-bar">
      <!-- 全部筛选 -->
      <view class="filter-item" :class="{ active: currentFilter === 'all' }">
        <picker @change="onSortChange" :value="sortIndex" :range="sortOptions">
          <view class="picker-content">
            <text>{{ currentSort }}</text>
            <text class="iconfont icon-arrow-down"></text>
          </view>
        </picker>
      </view>
      <view class="divider"></view>
      <!-- 窗口筛选 -->
      <view class="filter-item" :class="{ active: currentFilter === 'window' }">
        <picker @change="onWindowChange" :value="windowIndex" :range="windowOptions" range-key="name">
          <view class="picker-content">
            <text>{{ currentWindow }}</text>
            <text class="iconfont icon-arrow-down"></text>
          </view>
        </picker>
      </view>
    </view>

    <!-- 评价列表 -->
    <scroll-view class="evaluate-list" scroll-y>
      <view class="evaluate-item" v-for="(item, index) in filteredEvaluateList" :key="index">
        <image class="food-image" :src="item.image" mode="aspectFill" />
        <view class="evaluate-content">
          <view class="food-info">
            <text class="food-name">{{ item.name }}</text>
            <text class="window-name">{{ item.window }}</text>
          </view>
          <view class="rating">
            <text class="rating-score">{{ item.rating }}</text>
            <view class="rating-stars">
              <text class="star" v-for="i in 5" :key="i" :class="{ active: i <= item.rating }">★</text>
            </view>
          </view>
          <view class="comment">{{ item.comment }}</view>
        </view>
      </view>
    </scroll-view>

    <!-- 使用TabBar组件 -->
    <tab-bar></tab-bar>
  </view>
</template>

<script setup>
import { ref, computed } from 'vue';
import TabBar from '@/components/TabBar.vue';

// 当前筛选状态
const currentFilter = ref('all');

// 排序选项
const sortOptions = ['全部', '评分⬇', '评分⬆'];
const sortIndex = ref(0);
const currentSort = computed(() => sortOptions[sortIndex.value]);

// 窗口选项
const windowOptions = [
  { id: 0, name: '看窗口' },
  { id: 1, name: '一楼-面食窗口' },
  { id: 2, name: '一楼-米饭窗口' },
  { id: 3, name: '二楼-炒菜窗口' },
  { id: 4, name: '二楼-特色窗口' },
];
const windowIndex = ref(0);
const currentWindow = computed(() => windowOptions[windowIndex.value].name);

// 评价列表数据
const evaluateList = [
  {
    image: '/src/static/images/default.jpg',
    name: '小炒黄牛肉',
    window: '二楼-炒菜窗口',
    rating: 4.0,
    comment: '孩子很爱吃，下次还来！'
  },
  {
    image: '/static/images/default.jpg',
    name: '小炒黄牛肉',
    window: '二楼-炒菜窗口',
    rating: 4.5,
    comment: '孩子很爱吃，下次还来！'
  },
  {
    image: '/static/images/default.jpg',
    name: '小炒黄牛肉',
    window: '一楼-米饭窗口',
    rating: 3.5,
    comment: '孩子很爱吃，下次还来！'
  },
  {
    image: '/static/images/default.jpg',
    name: '小炒黄牛肉',
    window: '一楼-面食窗口',
    rating: 5.0,
    comment: '孩子很爱吃，下次还来！'
  }
];

// 过滤后的评价列表
const filteredEvaluateList = computed(() => {
  let result = [...evaluateList];
  
  // 按窗口筛选
  if (windowIndex.value !== 0) {
    const selectedWindow = windowOptions[windowIndex.value].name;
    result = result.filter(item => item.window === selectedWindow);
  }
  
  // 按评分排序
  if (sortIndex.value === 1) {
    // 评分从高到低
    result.sort((a, b) => b.rating - a.rating);
  } else if (sortIndex.value === 2) {
    // 评分从低到高
    result.sort((a, b) => a.rating - b.rating);
  }
  
  return result;
});

// 排序方式改变处理函数
const onSortChange = (e) => {
  sortIndex.value = e.detail.value;
  currentFilter.value = 'all';
};

// 窗口选择改变处理函数
const onWindowChange = (e) => {
  windowIndex.value = e.detail.value;
  currentFilter.value = 'window';
};
</script>

<style lang="scss">
.evaluate-container {
  min-height: 100vh;
  background: #f8f9fa;
  padding-bottom: 120rpx;
  box-sizing: border-box;
  position: relative;
}

.status-bar {
  height: 44rpx;
  width: 100%;
}

.filter-bar {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20rpx 30rpx;
  background: #fff;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
}

.filter-item {
  flex: 1;
  text-align: center;
  position: relative;
  transition: all 0.3s;

  &.active {
    color: #34c759;
    font-weight: 500;
  }
}

.picker-content {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16rpx 0;
  font-size: 28rpx;
  color: #666;

  .icon-arrow-down {
    font-size: 24rpx;
    margin-left: 8rpx;
  }
}

.divider {
  width: 2rpx;
  height: 24rpx;
  background: #eee;
  margin: 0 40rpx;
}

.evaluate-list {
  height: calc(100vh - 220rpx);
  padding: 0 30rpx;
}

.evaluate-item {
  display: flex;
  padding: 30rpx;
  background: #fff;
  border-radius: 24rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 4rpx 16rpx rgba(0, 0, 0, 0.05);
}

.food-image {
  width: 160rpx;
  height: 160rpx;
  border-radius: 12rpx;
  margin-right: 24rpx;
}

.evaluate-content {
  flex: 1;
}

.food-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16rpx;
}

.food-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
}

.window-name {
  font-size: 24rpx;
  color: #999;
}

.rating {
  display: flex;
  align-items: center;
  margin-bottom: 16rpx;
}

.rating-score {
  font-size: 36rpx;
  color: #34c759;
  font-weight: 600;
  margin-right: 16rpx;
}

.rating-stars {
  display: flex;
  align-items: center;
}

.star {
  font-size: 32rpx;
  color: #ddd;
  margin-right: 4rpx;

  &.active {
    color: #ffcd3c;
  }
}

.comment {
  font-size: 28rpx;
  color: #666;
  line-height: 1.5;
}
</style> 