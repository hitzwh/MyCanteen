<template>
	<view class="register-container">
		<!-- 返回按钮 -->
		<view class="back-button" @click="goBack">
			<text class="back-icon">&#xe602;</text>
		</view>
		
		<!-- Logo部分 -->
		<view class="logo-container">
			<view class="logo">
				<text class="logo-icon">C</text>
			</view>
		</view>
		
		<!-- 欢迎文本 -->
		<view class="welcome-text">
			<text class="title">创建账号</text>
			<text class="subtitle">请填写您的账号信息</text>
		</view>
		
		<!-- 表单部分 -->
		<view class="form-container">
			<view class="input-group">
				<text class="label">账号</text>
				<view class="input-wrapper">
					<input 
						type="text" 
						v-model="username" 
						placeholder="请输入您的账号"
						@focus="handleFocus('username')"
						@blur="handleBlur('username')"
					/>
					<text class="icon">&#xe600;</text>
				</view>
			</view>
			
			<view class="input-group">
				<text class="label">密码</text>
				<view class="input-wrapper">
					<input 
						:type="showPassword ? 'text' : 'password'" 
						v-model="password" 
						placeholder="请输入您的密码"
						@focus="handleFocus('password')"
						@blur="handleBlur('password')"
					/>
					<text class="icon" @click="togglePasswordVisibility">&#xe601;</text>
				</view>
			</view>
			
			<view class="input-group">
				<text class="label">确认密码</text>
				<view class="input-wrapper">
					<input 
						:type="showConfirmPassword ? 'text' : 'password'" 
						v-model="confirmPassword" 
						placeholder="请再次输入您的密码"
						@focus="handleFocus('confirmPassword')"
						@blur="handleBlur('confirmPassword')"
					/>
					<text class="icon" @click="toggleConfirmPasswordVisibility">&#xe601;</text>
				</view>
			</view>
			
			<!-- 注册按钮 -->
			<button class="register-button" @click="register">注 册</button>
			
			<!-- 登录选项 -->
			<view class="login-options">
				<text class="login-text">已有账号?</text>
				<text class="login-link" @click="goToLogin">立即登录</text>
			</view>
		</view>
	</view>
</template>

<script setup>
import { ref } from 'vue';

// 响应式数据
const username = ref('');
const password = ref('');
const confirmPassword = ref('');
const showPassword = ref(false);
const showConfirmPassword = ref(false);
const focusedField = ref('');

// 宫格按钮数据：定义功能入口
const gridBtns = [
	{ icon: 'icon-shouye', text: '餐厅介绍', badge: true },  // 第一个按钮，带徽标
	{ icon: 'icon-shouye', text: '饮食指导' },               // 第二个按钮
	{ icon: 'icon-shouye', text: '天猫美食' },               // 第三个按钮
	{ icon: 'icon-shouye', text: '预定包厢', badge: true },  // 第四个按钮，带徽标
	{ icon: 'icon-shouye', text: '后续开发' },               // 第五个按钮
];

// 处理输入框聚焦
const handleFocus = (field) => {
	focusedField.value = field;
};

// 处理输入框失焦
const handleBlur = (field) => {
	if (focusedField.value === field) {
		focusedField.value = '';
	}
};

// 切换密码可见性
const togglePasswordVisibility = () => {
	showPassword.value = !showPassword.value;
};

// 切换确认密码可见性
const toggleConfirmPasswordVisibility = () => {
	showConfirmPassword.value = !showConfirmPassword.value;
};

// 注册方法
const register = () => {
	if (!username.value || !password.value || !confirmPassword.value) {
		uni.showToast({
			title: '请填写完整注册信息',
			icon: 'none'
		});
		return;
	}
	
	if (password.value !== confirmPassword.value) {
		uni.showToast({
			title: '两次输入的密码不一致',
			icon: 'none'
		});
		return;
	}
	
	// 这里添加注册逻辑
	uni.showLoading({
		title: '注册中...'
	});
	
	// 模拟注册请求
	setTimeout(() => {
		uni.hideLoading();
		uni.showToast({
			title: '注册成功',
			icon: 'success'
		});
		
		// 注册成功后跳转到登录页
		setTimeout(() => {
			uni.navigateBack();
		}, 1500);
	}, 1500);
};

// 返回上一页
const goBack = () => {
	uni.navigateBack();
};

// 前往登录页面
const goToLogin = () => {
	uni.navigateBack();
};
</script>

<style lang="scss">
.register-container {
	min-height: 100vh;
	padding: 40rpx 60rpx;
	background: linear-gradient(135deg, #f8f9fa 0%, #e9f7e9 100%);
	display: flex;
	flex-direction: column;
	position: relative;
}

.back-button {
	position: absolute;
	top: 60rpx;
	left: 40rpx;
	width: 80rpx;
	height: 80rpx;
	display: flex;
	align-items: center;
	justify-content: center;
}

.back-icon {
	font-size: 40rpx;
	color: #333;
}

.logo-container {
	display: flex;
	justify-content: center;
	margin-top: 120rpx;
	margin-bottom: 80rpx;
}

.logo {
	width: 160rpx;
	height: 160rpx;
	background: linear-gradient(135deg, #34c759 0%, #2a9d4a 100%);
	border-radius: 40rpx;
	display: flex;
	align-items: center;
	justify-content: center;
	box-shadow: 0 16rpx 32rpx rgba(52, 199, 89, 0.3);
}

.logo-icon {
	color: white;
	font-size: 80rpx;
	font-weight: bold;
}

.welcome-text {
	text-align: center;
	margin-bottom: 80rpx;
}

.title {
	font-size: 48rpx;
	color: #333;
	margin-bottom: 16rpx;
	font-weight: 600;
	display: block;
}

.subtitle {
	font-size: 28rpx;
	color: #666;
	display: block;
}

.form-container {
	width: 100%;
}

.input-group {
	margin-bottom: 40rpx;
}

.label {
	display: block;
	font-size: 28rpx;
	color: #555;
	margin-bottom: 16rpx;
	font-weight: 500;
}

.input-wrapper {
	position: relative;
	display: flex;
	align-items: center;
}

input {
	width: 100%;
	height: 100rpx;
	padding: 0 30rpx;
	border: 2rpx solid #ddd;
	border-radius: 24rpx;
	font-size: 30rpx;
	background-color: white;
	transition: all 0.3s;
}

input:focus {
	border-color: #34c759;
	box-shadow: 0 0 0 6rpx rgba(52, 199, 89, 0.2);
}

.icon {
	position: absolute;
	right: 30rpx;
	font-size: 36rpx;
	color: #999;
}

.register-button {
	background: linear-gradient(135deg, #34c759 0%, #2a9d4a 100%);
	color: white;
	border: none;
	border-radius: 24rpx;
	padding: 32rpx;
	font-size: 32rpx;
	font-weight: 600;
	width: 100%;
	margin-top: 20rpx;
	margin-bottom: 60rpx;
	box-shadow: 0 16rpx 32rpx rgba(52, 199, 89, 0.3);
}

.register-button:active {
	transform: translateY(2rpx);
	box-shadow: 0 10rpx 20rpx rgba(52, 199, 89, 0.3);
}

.login-options {
	text-align: center;
	margin-top: 20rpx;
}

.login-text {
	font-size: 28rpx;
	color: #666;
}

.login-link {
	color: #34c759;
	font-size: 28rpx;
	font-weight: 600;
	margin-left: 10rpx;
}
</style> 