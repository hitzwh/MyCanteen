<template>
  <view>
    <router-view></router-view>
  </view>
</template>

<script>
export default {
  onLaunch: function() {
    console.log('App Launch');
    // 在应用启动时设置字体和样式
    this.initAppStyles();
  },
  onShow: function() {
    console.log('App Show');
  },
  onHide: function() {
    console.log('App Hide');
  },
  methods: {
    // 初始化应用样式
    initAppStyles() {
      // 检测平台
      const platform = uni.getSystemInfoSync().platform;
      
      // 设置平台特定样式
      if (platform === 'android') {
        // Android平台优化
        console.log('在Android平台上运行，应用特定样式优化');
        
        // 可以在此处设置平台特定的全局变量
        this.adjustIconSizes();
      }
    },
    
    // 调整图标大小以适应Android
    adjustIconSizes() {
      // 这里可以动态设置一些全局样式变量
      // 例如可以通过uni.addStyle添加特定于平台的样式
      // 或者设置全局变量供组件使用
    }
  }
}
</script>

<style>
/* 全局样式，确保内容在安全区域内 */
page {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  width: 100%;
  overflow-x: hidden; /* 防止水平滚动 */
}

/* 处理iphone X及以上机型的底部安全区 */
.safe-area-inset-bottom {
  padding-bottom: constant(safe-area-inset-bottom);
  padding-bottom: env(safe-area-inset-bottom);
}

/* 处理顶部状态栏 */
.safe-area-inset-top {
  padding-top: constant(safe-area-inset-top);
  padding-top: env(safe-area-inset-top);
}

/* 图标显示修复 */
.iconfont {
  font-family: "iconfont" !important;
  text-rendering: auto;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
}

/* Android平台特定样式 */
/* 设置更好的字体渲染 */
view, text, button, input {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}

/* 确保盒子间距一致 */
.container-wrapper {
  width: 100%;
  box-sizing: border-box;
  padding-left: 30rpx;
  padding-right: 30rpx;
}

/* 修复不同设备上的间距问题 */
.selector-area .selector-item,
.food-list .food-item {
  margin-bottom: 20rpx !important;
}

/* 修复Android上的图标显示问题 */
@supports (-webkit-touch-callout: none) {
  /* iOS设备 */
  .iconfont::before {
    /* 为iOS设备添加特定样式 */
    display: inline-block;
    vertical-align: middle;
    line-height: normal;
  }
}

@supports not (-webkit-touch-callout: none) {
  /* 非iOS设备（Android等） */
  .iconfont::before {
    display: inline-block !important;
    height: 1em;
    width: 1em;
    line-height: 1;
  }
}

/* 为徽标添加脉冲动画 */
@keyframes pulse {
  0% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.2);
    opacity: 0.8;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}
</style>

<style>
@import url('./static/iconfont/iconfont.css');
</style>

<style>
/* 全局样式优化 */
page {
  background-color: #f8f9fc;
  color: #333;
  font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', 'PingFang SC', 'Microsoft YaHei', 'Source Han Sans SC', 'Noto Sans CJK SC', sans-serif;
}

/* 优化全局背景 */
.page-background {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, rgba(248, 249, 252, 0.95) 0%, rgba(255, 255, 255, 0.95) 100%);
  background-attachment: fixed;
  z-index: -1;
}

/* 背景装饰元素 */
.bg-decoration {
  position: fixed;
  z-index: -1;
  border-radius: 50%;
  opacity: 0.5;
  filter: blur(30px);
}

.bg-decoration-1 {
  top: -5%;
  right: -10%;
  width: 300rpx;
  height: 300rpx;
  background: linear-gradient(45deg, rgba(52, 199, 89, 0.2), rgba(64, 156, 255, 0.2));
}

.bg-decoration-2 {
  bottom: 10%;
  left: -10%;
  width: 400rpx;
  height: 400rpx;
  background: linear-gradient(135deg, rgba(255, 149, 0, 0.15), rgba(255, 59, 48, 0.15));
}

/* 卡片样式优化 */
.card {
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 20rpx;
  box-shadow: 0 8rpx 30rpx rgba(0, 0, 0, 0.05), 0 2rpx 8rpx rgba(0, 0, 0, 0.03);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.7);
  transition: all 0.3s ease;
}

.card:active {
  transform: translateY(-2rpx);
  box-shadow: 0 12rpx 40rpx rgba(0, 0, 0, 0.08), 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
}

/* 按钮样式优化 */
.btn {
  background: linear-gradient(135deg, #34c759, #32ade6);
  color: white;
  border-radius: 50rpx;
  padding: 24rpx 40rpx;
  font-weight: 500;
  box-shadow: 0 8rpx 20rpx rgba(52, 199, 89, 0.3);
  border: none;
  transition: all 0.3s ease;
}

.btn:active {
  transform: translateY(2rpx);
  box-shadow: 0 4rpx 10rpx rgba(52, 199, 89, 0.2);
}

/* 输入框样式优化 */
.input {
  background-color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.05);
  border-radius: 16rpx;
  padding: 20rpx 30rpx;
  transition: all 0.3s ease;
}

.input:focus {
  border-color: rgba(52, 199, 89, 0.5);
  box-shadow: 0 0 0 3px rgba(52, 199, 89, 0.1);
}

/* 标题样式优化 */
.section-title {
  font-weight: 600;
  color: #333;
  position: relative;
  padding-left: 24rpx;
  margin-bottom: 30rpx;
}

.section-title::before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 8rpx;
  height: 32rpx;
  background: linear-gradient(to bottom, #34c759, #32ade6);
  border-radius: 4rpx;
}

/* 列表项样式优化 */
.list-item {
  background-color: rgba(255, 255, 255, 0.7);
  border-radius: 16rpx;
  margin-bottom: 20rpx;
  padding: 24rpx;
  box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.7);
  transition: all 0.3s ease;
}

.list-item:active {
  background-color: rgba(255, 255, 255, 0.9);
  transform: translateY(-2rpx);
}

/* 标签样式优化 */
.tag {
  background-color: rgba(52, 199, 89, 0.1);
  color: #34c759;
  border-radius: 30rpx;
  padding: 8rpx 20rpx;
  font-size: 24rpx;
  font-weight: 500;
  margin-right: 16rpx;
  border: 1px solid rgba(52, 199, 89, 0.2);
}
</style>
